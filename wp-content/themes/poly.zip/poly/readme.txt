=== Theme Update ===

License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

=== Changelog ===

0.5
* Folder re-structure
* Adding a css file
* Revise functions.php
* Revise styles.css
* Revise theme description

0.4
* Folder re-structure
* Adding some tag on style.css
