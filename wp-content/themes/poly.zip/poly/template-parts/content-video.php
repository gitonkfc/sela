<?php
/**
 * @package poly
 */
?>

<div class="container">

	<?php poly_post_thumbnail(); ?>

	<div class="row content-poly justify-content-center">
			<?php the_title( '<h1 class="entry-title">', '</h1>' ); ?>

	</div><!-- .entry-header -->

	<div class="row content-poly justify-content-center">
		<div class="col-lg-8 text-justify">
			<?php the_content( __( 'Continue reading <span class="meta-nav">&rarr;</span>', 'poly' ) ); ?>
		</div><!-- .entry-content -->

		<?php poly_author_bio(); ?>
	</div><!-- .entry-body -->

</div><!-- #post-## -->
