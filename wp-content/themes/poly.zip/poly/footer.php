<?php
/**
 * The template for displaying the footer.
 *
 * @package poly
 */
?>

	</div><!-- #content -->


    <footer class="poly-footer bg-dark">
        <p class="m-0 text-center text-white">Copyright 2018 Polycrol Indonesia All Right Reserved</p>
      <!-- /.container -->
    </footer>
</div><!-- #page -->

<?php wp_footer(); ?>

</body>
</html>
