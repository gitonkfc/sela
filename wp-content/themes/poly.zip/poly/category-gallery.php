<?php
/**
 * The template for displaying Archive pages.
 *
<<<<<<< HEAD
 * @package poly
 */

get_header(); ?>
		<?php if ( have_posts() ) : ?>

		<div class="container">
			<div class="row justify-content-center poly-category">
					<h1><?php single_cat_title(); ?></h1>
			</div><!-- .page-header -->

			<?php while ( have_posts() ) : the_post(); ?>
    			<div class="row content-poly justify-content-center">
        			<div class="col-md-10">
        				<div class="embed-responsive embed-responsive-16by9">
        				<?php $content = apply_filters( 'the_content', $post->post_content );
							$embeds = get_media_embedded_in_content( $content );?>
							<?php 
							echo $embeds[0];
						?>
						</div>
						<br>
				  	   	<a href="<?php echo get_permalink( $post );?>"><h4 class="title font-weight-bold"><?php echo esc_attr($post->post_title)?></h4></a>
						<br>
						<p class="text-justify category-group"><?php echo $post->post_excerpt;?></p>
        			</div>
        			<hr class="poly">
    			</div>
			<?php endwhile; ?>
		<?php endif; ?>

	</div>
<?php get_sidebar(); ?>
<?php get_footer(); ?>

