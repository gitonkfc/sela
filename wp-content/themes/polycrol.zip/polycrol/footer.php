<?php
?>
<footer class="footer">
	<div class="container">
  		<p class="copyright"> Copyright 2018 Polycroll Indonesia All Right Reserved</p>
	</div>
</footer>
<?php wp_footer(); ?>
</body>
</html>
